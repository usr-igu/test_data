Mixed test archive with generated royalty-free sample files.
